<template>
  <div>
    <Header></Header>
    <h1>Welcome to Update page of Restaurent management app</h1>
    <div>
      <form class="upd">
        <input type="text" v-model="restaurant.name" placeholder="Enter Name" />
        <input type="text" v-model="restaurant.contact" placeholder="Enter Contact" />
        <input type="text" v-model="restaurant.address" placeholder="Enter Address" />
        <button type="button" v-on:click="updRestaurant">Update Restaurant</button>
      </form>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import Header from "./Header.vue";

export default {
  name: "UpdateComponent",
  components: {
    Header,
  },
  data(){
    return {
      restaurant: {
        name: '',
        contact: '',
        address: '',
      }
    }
  },
  methods: {
    async updRestaurant() {
      console.log(this.restaurant)
      const result = await axios.put("http://localhost:3000/restaurant/" + this.$route.params.id, {
        name:this.restaurant.name,
        contact:this.restaurant.contact,
        address:this.restaurant.address
      });
      if(result.status == 200) {
        this.$router.push({name:"Home"});
      }
    }
  },
  async mounted() {
    let user = localStorage.getItem("user-info");
    if (!user) {
      this.$router.push({ name: "Signup" });
    }
    console.log(this.$route.params.id)
    const result = await axios.get('http://localhost:3000/restaurant/' + this.$route.params.id);
    console.log(result.data)
    this.restaurant = result.data 
  },
};
</script>
