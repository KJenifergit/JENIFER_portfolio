<template>
  <div>
    <Header></Header>
    <h1>Welcome to Add page of Restaurent management app</h1>
    <div>
      <form class="add">
        <input type="text" v-model="restaurant.name" placeholder="Enter Name" />
        <input type="text" v-model="restaurant.contact" placeholder="Enter Contact" />
        <input type="text" v-model="restaurant.address" placeholder="Enter Address" />
        <button type="button" v-on:click="addRestaurant">Add new restaurant</button>
      </form>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import Header from "./Header.vue";

export default {
  name: "AddComponent",
  components: {
    Header,
  },
  data(){
    return {
      restaurant: {
        name: '',
        contact: '',
        address: '',
      }
    }
  },
  methods: {
    async addRestaurant() {
      console.log(this.restaurant);
      let result = await axios.post("http://localhost:3000/restaurant" , {
        name:this.restaurant.name,
        contact:this.restaurant.contact,
        address:this.restaurant.address
      });
      console.log(result);
      if(result.status == 201) {
        this.$router.push({name:"Home"});
      }
    }
  },
  mounted() {
    let user = localStorage.getItem("user-info");
    if (!user) {
      this.$router.push({ name: "Signup" });
    }
  },
};
</script>
