<template>
  <div>
    <img class="logo" src="../assets/signup.webp" />
    <h1>Sign Up</h1>
    <div class="register">
        <input type="text" v-model="name" placeholder="Enter Name" />
        <input type="text" v-model="email" placeholder="Enter Email" />
        <input type="password" v-model="password" placeholder="Enter Password" />
        <button v-on:click="signUp">Sign Up</button>
        <p>
          <router-link to="/login">Login Page</router-link>
        </p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: "SignupComponent",
  data() {
    return {
        name: '',
        email: '',
        password: '',
    }
  },
  methods: {
    async signUp() {
        let response = await axios.post("http://localhost:3000/users", {
            name: this.name,
            email: this.email,
            password: this.password
        });
        console.log(response);
        if(response.status == 201){
            alert("Sign-up is done");
            localStorage.setItem("user-info", JSON.stringify(response.data))
            this.$router.push({name:'Home'})
        }
    },
  },
  mounted() {
    let user = localStorage.getItem('user-info');
    if(user){
      this.$router.push({name: 'Home'})
    }
  },
};
</script>

<style scoped>

</style>