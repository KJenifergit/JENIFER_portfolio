<template>
  <div>
    <img class="logo" src="../assets/signup.webp" />
    <h1>Login</h1>
    <div class="login">
      <input type="text" v-model="email" placeholder="Enter Email" />
      <input type="password" v-model="password" placeholder="Enter Password" />
      <button v-on:click="login">Login</button>
      <p>
        <router-link to="/signup">Sign-up</router-link>
      </p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: "LoginComponent",
  data() {
    return {
        email:'',
        password: ''
    }
  },
  methods: {
    async login() {
        console.log(this.email, this.password)
        let res = await axios.get(
            `http://localhost:3000/users?email=${this.email}&password=${this.password}`
        )
        if(res.status == 200 && res.data.length>0) {
            localStorage.setItem("user-info", JSON.stringify(res.data[0]))
            this.$router.push({name: "Home"})
        }
        console.log(res);
    }
  },
  mounted() {
    let user = localStorage.getItem('user-info');
    if(user){
      this.$router.push({name: 'Home'})
    }
  },
};
</script>

<style scoped>

</style>
