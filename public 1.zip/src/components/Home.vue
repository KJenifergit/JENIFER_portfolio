<template>
  <div>
    <Header></Header>
    <h1>Hello {{ name }}, Welcome to Home page</h1>
    <div>
      <table class="table">
        <thead>
          <tr>
            <td>Id</td>
            <td>Name</td>
            <td>Contact</td>
            <td>Address</td>
            <td>Action</td>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, num) in restaurant" :key="item.id">
            <td>{{ num + 1 }}</td>
            <td>{{ item.name }}</td>
            <td>{{ item.contact }}</td>
            <td>{{ item.address }}</td>
            <td>
              <router-link :to="'/update/' + item.id">Edit</router-link>
              <button v-on:click="deleteRestaurant(item.id)">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import Header from "./Header.vue";

export default {
  name: "HomeComponent",
  data() {
    return {
      name: "",
      restaurant: [],
    };
  },
  components: {
    Header,
  },
  methods: {
    async deleteRestaurant(id) {
      console.log(id);
      let result = await axios.delete("http://localhost:3000/restaurant/" + id);
      console.log(result);
      if (result.status == 200) {
        this.loadData();
      }
    },
    async loadData() {
      let user = localStorage.getItem("user-info");
      this.name = JSON.parse(user).name;
      console.log(this.name);
      if (!user) {
        this.$router.push({ name: "Signup" });
      }
      let result = await axios.get("http://localhost:3000/restaurant");
      console.log(result);
      this.restaurant = result.data;
    },
  },
  mounted() {
    this.loadData();
  },
};
</script>

<style scoped>
table {
  margin-top: 20px;
  border-collapse: collapse;
  width: 80%;
  margin-left: auto;
  margin-right: auto;
}

th,
td {
  border: 1px solid black;
  padding: 8px;
  text-align: left;
}

th {
  background-color: #f2f2f2;
}
</style>
