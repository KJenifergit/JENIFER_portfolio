package com.Dao;

public class Booking {
	//Filght Details;
	public static String filght_id;
	public static int ticket_price;
	public static String flight_name;
	
	//Passenger Details;
	public static String passenger_name;
	public static String passenger_email;
	public static String passenger_phone;
	
	//Payment Details;
	public static String name_on_card;
	public static String mobileno;
}
