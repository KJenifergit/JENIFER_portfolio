import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.lang.String;
import java.lang.Integer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Insert
 */
@WebServlet("/Insert")
public class Insert extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 public Insert() {
	        // TODO Auto-generated constructor stub
	    }
	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}

    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		 DateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
		 DateFormat formatter = new SimpleDateFormat ("hh:mm:ss a"); 
		 
		

         
		
    int flightid=Integer.parseInt(request.getParameter("flightid"));
	String name =request.getParameter("name");
	String origin =request.getParameter("origin");
   String DATE =(request.getParameter("DATE"));
	String TIME =(request.getParameter("TIME"));
	String Destination =request.getParameter("Destination");
	
	
	Connection con=null;
	 try {
		 Class.forName("com.mysql.cj.jdbc.Driver");
		 String url="jdbc:mysql://localhost:3306/goblin";
		 String uname="root";
		 String pwd="Yuvarani06@";
		 con = DriverManager.getConnection(url,uname,pwd);
		 String query="insert into flight values(?,?,?,?,?,?)";
		 PreparedStatement ps= con.prepareStatement(query);
		 ps.setInt(1,flightid);
		 ps.setString(2,name);
		 ps.setString(3,origin);
		 ps.setDate(4,java.sql.Date.valueOf(DATE));
		 ps.setTimestamp(5,java.sql.Timestamp.valueOf(TIME));
		 ps.setString(6,Destination);
		 int count =ps.executeUpdate();
		 if (count>0) {
			 out.println("Data Inserted Successfully");
			 
		 }else
		 {
			 out.println("Failed in insertion"); 
		 }
		 
		 
		 
	 }catch(Exception e) {
		out.println("Exception :"+e.getMessage());
	 }
	 finally {
		 if(con!=null)
		 {
			 try {
				 con.close();
			 }
			 catch (SQLException e)
			 {
				 e.printStackTrace();
			 }
		 }
	 }
	 }

	
	}


